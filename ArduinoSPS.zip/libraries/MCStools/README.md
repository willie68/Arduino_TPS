# RCReceiver
An arduino library for comunicate with a rc receiver
